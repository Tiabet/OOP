public class FloatDataTypeExample  
{  
public static void main(String args[])   
{  
float x = 2.0f, y = 3.0f;   //defining x and y as float  
float z = x / y;            //divides x by y and stores the result in the variable z  
System.out.println("x/y = " + z);   //prints the result  
System.out.println("x/y = " + (int)z);   //prints the result  
}  
}
